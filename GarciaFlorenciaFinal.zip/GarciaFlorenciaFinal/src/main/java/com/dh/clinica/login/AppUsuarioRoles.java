package com.dh.clinica.login;

public enum AppUsuarioRoles {
    USER,ADMIN;
}
